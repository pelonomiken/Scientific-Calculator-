package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button buttonCalculator;
    Button buttonSettings;
    Button buttonHelp;
    TextView textViewDevelopername;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonCalculator=findViewById(R.id.buttonCalculator);
        buttonCalculator.setOnClickListener(this);


        buttonSettings=findViewById(R.id.buttonSettings);
        buttonSettings.setOnClickListener(this);

        buttonHelp=findViewById(R.id.buttonHelp);
        buttonHelp.setOnClickListener(this);

        textViewDevelopername=findViewById(R.id.textViewDevelopername);


    }

    @Override
public void onClick(View view){
        int id = view.getId();
        if (id == R.id.buttonCalculator) {
            Intent intent = new Intent(this, CalculatorActivity.class);
            startActivity(intent);
            Toast.makeText(this, "Calculator", Toast.LENGTH_SHORT).show();

        }
        if (id == R.id.buttonSettings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            Toast.makeText(this, "Settings", Toast.LENGTH_SHORT).show();

        } else if (id == R.id.buttonHelp) {
            Intent intent = new Intent(this, HelpActivity.class);
            startActivity(intent);
            Toast.makeText(this, "Help", Toast.LENGTH_SHORT).show();


        }
    }
}