package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class CalculatorActivity extends AppCompatActivity implements View.OnClickListener{

    TextView TVPrimary, TVSecondary;
    Button BtnMr;
    Button BtnMC;
    Button BtnAC;
    Button BtnC;
    Button Btnsin;
    Button Btnsin2;
    Button BtnOnex;
    Button Btnx;
    Button Btncos;
    Button Btncos2;
    Button Btnx2;
    Button Btntenx;
    Button Btntan;
    Button Btntan2;
    Button Btnln;
    Button Btnex;
    Button Btnlog10;
    Button Btnbrac1;
    Button Btnbrac2;
    Button Btnpie;
    Button Btnpercent;
    Button Btn7;
    Button Btn8;
    Button Btn9;
    Button Btndiv;
    Button Btn4;
    Button Btn5;
    Button Btn6;
    Button Btnmul;
    Button Btn1;
    Button Btn2;
    Button Btn3;
    Button Btnmin;
    Button Btnplusminus;
    Button Btn0;
    Button Btndot;
    Button Btnadd;
    Button Btnequals;
    Button Btnback;
    Button Btnsave;
    String sign, value1, value2;
    Double num1, num2, result;
    boolean hasDot;

    SharedPreferences myPreference = null;
    SharedPreferences.Editor editor = null;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);

        TVPrimary = findViewById(R.id.TVPrimary);
        TVSecondary = findViewById(R.id.TVSecondary);

        hasDot = false;


        BtnMr = findViewById(R.id.BtnMR);
        BtnMr.setOnClickListener(this);


        BtnMC = findViewById(R.id.BtnMC);
        BtnMC.setOnClickListener(this);


        BtnAC = findViewById(R.id.BtnAC);
        BtnAC.setOnClickListener(this);


        BtnC = findViewById(R.id.BtnC);
        BtnC.setOnClickListener(this);

        Btnsave = (Button) findViewById(R.id.Btnsave);
        Btnsave.setOnClickListener(this);

        Btnback = findViewById(R.id.Btnback);
        Btnback.setOnClickListener(this);


        Btnsin2 = findViewById(R.id.Btnsin2);
        Btncos2 = findViewById(R.id.Btncos2);
        BtnOnex = findViewById(R.id.BtnOnex);
        Btnx2 = findViewById(R.id.Btnx2);
        Btntan2 = findViewById(R.id.Btntan2);
        Btnpercent = findViewById(R.id.Btnpercent);
        Btnx = findViewById(R.id.Btnx);
        Btncos = findViewById(R.id.Btncos);
        Btntenx = findViewById(R.id.Btntenx);
        Btntan = findViewById(R.id.Btntan);
        Btnln = findViewById(R.id.Btnln);
        Btnex = findViewById(R.id.Btnenx);
        Btn7 = findViewById(R.id.Btn7);
        Btn8 = findViewById(R.id.Btn8);
        Btn9 = findViewById(R.id.Btn9);
        Btndiv = findViewById(R.id.Btndiv);
        Btn4 = findViewById(R.id.Btn4);
        Btn5 = findViewById(R.id.Btn5);
        Btn6 = findViewById(R.id.Btn6);
        Btnmul = findViewById(R.id.Btnmul);
        Btn1 = findViewById(R.id.Btn1);
        Btn2 = findViewById(R.id.Btn2);
        Btn3 = findViewById(R.id.Btn3);
        Btnmin = findViewById(R.id.Btnmin);
        Btnplusminus = findViewById(R.id.Btnplusminus);
        Btn0 = findViewById(R.id.Btn0);
        Btndot = findViewById(R.id.Btndot);
        Btnadd = findViewById(R.id.Btnadd);
        Btnequals = findViewById(R.id.Btnequals);
        Btnbrac2 = findViewById(R.id.Btnbrac2);
        Btnbrac1 = findViewById(R.id.Btnbrac1);
        Btnpie = findViewById(R.id.Btnpie);
        Btnlog10=findViewById(R.id.Btnlog10);
        Btnsin=findViewById(R.id.Btnsin);



        //OnClick listeners for the number buttons
        Btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TVPrimary.setText(TVPrimary.getText() + "1");
            }
        });

        Btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TVPrimary.setText(TVPrimary.getText() + "2");
            }
        });

        Btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TVPrimary.setText(TVPrimary.getText() + "3");
            }
        });

        Btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TVPrimary.setText(TVPrimary.getText() + "4");
            }
        });

        Btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TVPrimary.setText(TVPrimary.getText() + "5");
            }
        });

        Btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TVPrimary.setText(TVPrimary.getText() + "6");
            }
        });

        Btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TVPrimary.setText(TVPrimary.getText() + "7");
            }
        });

        Btn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TVPrimary.setText(TVPrimary.getText() + "8");
            }
        });

        Btn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TVPrimary.setText(TVPrimary.getText() + "9");
            }
        });

        Btn0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TVPrimary.setText(TVPrimary.getText() + "0");
            }
        });


        Btnbrac1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TVPrimary.setText(TVPrimary.getText() + "(");
            }
        });



        Btnbrac2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TVPrimary.setText(TVPrimary.getText() + ")");
            }
        });






        Btndot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!hasDot) {
                    if (TVPrimary.getText().equals("")) {

                        TVPrimary.setText("0.");
                    } else {

                        TVPrimary.setText(TVPrimary.getText() + ".");
                    }

                    hasDot = true;
                }

            }

        });
        Btnplusminus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sign = "±";
                value1 = TVPrimary.getText().toString();
                TVPrimary.setText(null);
                TVSecondary.setText("±");
                hasDot = false;
            }
        });


        //basic math and scientific function calculations
        Btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sign = "+";
                value1 = TVPrimary.getText().toString();
                TVPrimary.setText(null);
                TVSecondary.setText("+");
                hasDot = false;
            }
        });


        Btnpercent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sign = "%";
                value1 = TVPrimary.getText().toString();
                TVPrimary.setText(null);
                TVSecondary.setText("%");
                hasDot = false;
            }
        });

        Btnmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sign = "-";
                value1 = TVPrimary.getText().toString();
                TVPrimary.setText(null);
                TVSecondary.setText("-");
                hasDot = false;
            }
        });

        Btndiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sign = "/";
                value1 = TVPrimary.getText().toString();
                TVPrimary.setText(null);
                TVSecondary.setText("/");
                hasDot = false;
            }
        });

        Btnmul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sign = "*";
                value1 = TVPrimary.getText().toString();
                TVPrimary.setText(null);
                TVSecondary.setText("*");
                hasDot = false;
            }
        });
        Btnln.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sign = "ln";
                TVPrimary.setText(null);
                TVSecondary.setText("2.718281828459");
                hasDot = false;
            }
        });

        Btnlog10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sign = "log10";
                TVPrimary.setText(null);
                TVSecondary.setText("2.302585");
                hasDot = false;
            }
        });

        Btnpie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sign = "π";
                TVPrimary.setText(null);
                TVSecondary.setText("π");
                hasDot = false;
            }
        });

        BtnOnex.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sign = "1/x";
                value1 = TVPrimary.getText().toString();
                TVPrimary.setText(null);
                hasDot = false;
                TVSecondary.setText("1/x");
            }
        });

        Btnx.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sign = "x y";
                value1 = TVPrimary.getText().toString();
                TVPrimary.setText(null);
                hasDot = false;
                TVSecondary.setText("x*y");
            }
        });

        Btnx2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sign = "x 1/y";
                value1 = TVPrimary.getText().toString();
                TVPrimary.setText(null);
                hasDot = false;
                TVSecondary.setText("x 1/y");
            }
        });

        Btntenx.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sign = "10x";
                value1 = TVPrimary.getText().toString();
                TVPrimary.setText(null);
                hasDot = false;
                TVSecondary.setText("10x");
            }
        });


        Btnex.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sign = "ex";
                value1 = TVPrimary.getText().toString();
                TVPrimary.setText(null);
                hasDot = false;
                TVSecondary.setText("ex");
            }
        });
        Btnsin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sign = "sin";
                TVPrimary.setText(null);
                hasDot = false;
                TVSecondary.setText("sin");
            }
        });
        Btncos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sign = "cos";
                TVPrimary.setText(null);
                hasDot = false;
                TVSecondary.setText("cos");
            }
        });
        Btntan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sign = "tan";
                TVPrimary.setText(null);
                hasDot = false;
                TVSecondary.setText("tan");
            }
        });


        Btnsin2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sign = "sin-1";
                TVPrimary.setText(null);
                TVSecondary.setText("sin-1");
                hasDot = false;
            }
        });
        Btncos2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sign = "cos-1";
                TVPrimary.setText(null);
                TVSecondary.setText("cos-1");
                hasDot = false;
            }
        });
        Btntan2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sign = "tan-1";
                TVPrimary.setText(null);
                TVSecondary.setText("tan-1");
                hasDot = false;

            }
        });
        //Equal button incased with switch method which
        Btnequals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {//equal button that implements a switch statememnt which executes the calculations for my buttons
                if (sign == null) {//checks if the String sign is empty
                    TVSecondary.setText("Error!");
                } else if (TVPrimary.getText().equals("")) {//when a user does not click on a sign operator it displays on the text area an error message
                    TVSecondary.setText("Error!");
                } else if ((sign.equals("+") || sign.equals("-") || sign.equals("*") || sign.equals("/")) && value1.equals("")) {
                    TVSecondary.setText("Error!");
                } else {
                    switch (sign) {
                        default:
                            break;
                        case "log10":
                            value1 = TVPrimary.getText().toString();
                            num1 = Double.parseDouble(value1);
                            TVPrimary.setText(Math.log10(num1) + "");
                            sign = null;
                            TVSecondary.setText(null);
                            break;
                        case "ln":
                            value1 = TVPrimary.getText().toString();
                            num1 = Double.parseDouble(value1);
                            TVPrimary.setText(Math.log(num1) + "");
                            sign = null;
                            TVSecondary.setText(null);
                            break;
                        case "ex":
                            num1 = Double.parseDouble((value1));
                            value2 = TVPrimary.getText().toString();
                            num2 = Double.parseDouble(value2);
                            TVPrimary.setText(Math.pow(num1, num2) + "");
                            sign = null;
                            TVSecondary.setText(null);
                            break;
                        case "1/x":
                            num1 = Double.parseDouble((value1));
                            value2 = TVPrimary.getText().toString();
                            num2 = Double.parseDouble(value2);
                            TVPrimary.setText(Math.pow(num1, num2) + "");
                            sign = null;
                            TVSecondary.setText(null);
                            break;
                        case "x/y":
                            num1 = Double.parseDouble((value1));
                            value2 = TVPrimary.getText().toString();
                            num2 = Double.parseDouble(value2);
                            TVPrimary.setText(Math.pow(num1, num2) + "");
                            sign = null;
                            TVSecondary.setText(null);
                            break;
                        case "x 1/y":
                            num1 = Double.parseDouble((value1));
                            value2 = TVPrimary.getText().toString();
                            num2 = Double.parseDouble(value2);
                            TVPrimary.setText(Math.pow(num1, num2) + "");
                            sign = null;
                            TVSecondary.setText(null);
                            break;
                        case "10x":
                            num1 = Double.parseDouble((value1));
                            value2 = TVPrimary.getText().toString();
                            num2 = Double.parseDouble(value2);
                            TVPrimary.setText(Math.pow(num1, num2) + "");
                            sign = null;
                            TVSecondary.setText(null);
                            break;
                        /*case "π":
                            //num1 = Double.parseDouble((value1));
                            value1 = TVPrimary.getText().toString();
                            num1 = Double.parseDouble(value1);
                            TVPrimary.setText(Math.PI(num1, num2) + "");
                            sign = null;
                            TVSecondary.setText(null);
                            break;*/
                        case "sin-1":
                            value1 = TVPrimary.getText().toString();
                            num1 = Double.parseDouble((value1));
                            TVPrimary.setText(Math.sinh(num1) + "");
                            sign = null;
                            TVSecondary.setText(null);
                            break;
                        case "cos-1":
                            value1 = TVPrimary.getText().toString();
                            num1 = Double.parseDouble((value1));
                            TVPrimary.setText(Math.cosh(num1) + "");
                            sign = null;
                            TVSecondary.setText(null);
                            break;
                        case "tan-1":
                            value1 = TVPrimary.getText().toString();
                            num1 = Double.parseDouble((value1));
                            TVPrimary.setText(Math.tanh(num1) + "");
                            sign = null;
                            TVSecondary.setText(null);
                            break;
                        case "sin":
                            value1 = TVPrimary.getText().toString();
                            num1 = Double.parseDouble((value1));
                            TVPrimary.setText(Math.sin(num1) + "");
                            sign = null;
                            TVSecondary.setText(null);
                            break;
                        case "cos":
                            value1 = TVPrimary.getText().toString();
                            num1 = Double.parseDouble((value1));
                            TVPrimary.setText(Math.cos(num1) + "");
                            sign = null;
                            TVSecondary.setText(null);
                            break;
                        case "tan":
                            value1 = TVPrimary.getText().toString();
                            num1 = Double.parseDouble((value1));
                            TVPrimary.setText(Math.tan(num1) + "");
                            sign = null;
                            TVSecondary.setText(null);
                            break;
                        case "+":
                            value2 = TVPrimary.getText().toString();
                            num1 = Double.parseDouble(value1);
                            num2 = Double.parseDouble(value2);
                            result = num1 + num2;
                            TVPrimary.setText(result + "");
                            sign = null;
                            TVSecondary.setText(null);
                            break;
                        case "-":
                            value2 = TVPrimary.getText().toString();
                            num1 = Double.parseDouble(value1);
                            num2 = Double.parseDouble(value2);
                            result = num1 - num2;
                            TVPrimary.setText(result + "");
                            sign = null;
                            TVSecondary.setText(null);
                            break;
                        case "*":
                            value2 = TVPrimary.getText().toString();
                            num1 = Double.parseDouble(value1);
                            num2 = Double.parseDouble(value2);
                            result = num1 * num2;
                            TVPrimary.setText(result + "");
                            sign = null;
                            TVSecondary.setText(null);
                            break;
                        case "/":
                            value2 = TVPrimary.getText().toString();
                            num1 = Double.parseDouble(value1);
                            num2 = Double.parseDouble(value2);
                            result = num1 / num2;
                            TVPrimary.setText(result + "");
                            sign = null;
                            TVSecondary.setText(null);
                            break;
                        case "%":
                            value2 = TVPrimary.getText().toString();
                            num1 = Double.parseDouble(value1);
                            num2 = Double.parseDouble(value2);
                            result = num1 % num2;
                            TVPrimary.setText(result + "");
                            sign = null;
                            TVSecondary.setText(null);
                            break;
                        /*case "±":
                            value2 = TVPrimary.getText().toString();
                             int num1 = Integer.parseInt(value1);
                             int num2 = Integer.parseInt(value2);
                            result = Math.abs(num1,num2);
                            TVPrimary.setText(result + "");
                            sign = null;
                            TVSecondary.setText(null);
                            break;*/
                    }

                }
            }

        });


        myPreference = getPreferences(Context.MODE_PRIVATE);
        editor = myPreference.edit();


    }


    @Override
    public void onClick(View view) {

        int id = view.getId();

        if (id == R.id.Btnback) {

            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);

        }


        if (id == R.id.BtnC) {
            String val = TVPrimary.getText().toString();
            val = val.substring(0, val.length() - 1);
            TVPrimary.setText(val);
        }
        if (id == R.id.BtnAC) {
            TVPrimary.setText("");
            TVSecondary.setText("");
        }
        if (id == R.id.BtnMC) {
            resetMethod();
            TVPrimary.getText();

        }
        if (id == R.id.BtnMR) {
            recallMethod();
            TVPrimary.getText();

        } else if (id == R.id.Btnsave) {
            float number = 0;
            savedPreferances(number);

        }


    }



//saves previous calculations to the memory
    private void savedPreferances(float number) {
        editor.putFloat("Memory", number);
        editor.commit();
        Toast.makeText(this, "Save", Toast.LENGTH_SHORT).show();
    }

    //displays previous calculations in the memory
    public float recallMethod() {
        float number = myPreference.getFloat("memory", 0);
        return number;
    }

    //deletes stored calculations in the memory
    public void resetMethod() {
        TVPrimary.setText("");
        editor.clear();
    }
}


